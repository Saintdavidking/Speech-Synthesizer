<div align="center">
  <img src="https://github.com/asaoluelijah/say-it/blob/master/img/logo.png?raw=true" width="200" alt="Say It">

[![Pull Requests Welcome](https://img.shields.io/badge/PRs-welcome-red.svg?style=flat)](http://makeapullrequest.com)
[![Made in Nigeria](https://img.shields.io/badge/made%20in-nigeria-008751.svg?style=flat-square)](https://github.com/acekyd/made-in-nigeria)
</div>

Easily convert spoken words to text and instantly share across various social media.
***
#### View the project live  [here](https://asaoluelijah.github.io/say-it)

# Screenshots
<p>
    <img src="https://github.com/asaoluelijah/say-it/blob/master/img/screenshots/mobile.png?raw=true" width="200" alt="Desktop View 2">
</p>

# License

This project is open source and available under the [GNU GENERAL PUBLIC LICENSE](https://github.com/asaoluelijah/say-it/blob/master/LICENSE).

# Author

Made with ❤ by Asaolu Elijah
